# MyPetsFriends ERP | Entrega académica (código público)

Proyecto de ERP veterinario con Odoo Community 20.0, PostgreSQL 16 y Docker Compose. Incluye módulo propio, scripts, archivos CSV ficticios y guías técnicas.

## Estado verificado durante la implementación local
- Docker y Docker Compose comprobados mediante consola.
- PostgreSQL inició en estado healthy.
- La base `mypetsfriends` y la instalación del módulo veterinario completaron el proceso de inicialización.
- El servidor Odoo inició en `http://localhost:8069` y se verificó el acceso con usuario administrador.
- La **carga de datos** se inició, pero su resultado final y conteos aún deben validarse.
- Persistencia tras recrear contenedores, respaldo/restauración y flujo cita→atención→venta→factura **pendientes de evidencia**.

## Inicio local
1. Instalar Docker Desktop (WSL 2) y Python.
2. Ejecutar `python scripts/install.py` desde la carpeta del proyecto; crea `.env` y `config/odoo.conf` **solo localmente**.
3. Ingresar a `http://localhost:8069` y obtener las credenciales desde el archivo `.env` local.
4. Ejecutar `python scripts/load_demo.py` y comprobar el mensaje final y los conteos dentro del ERP.
5. Para respaldo, ejecutar `python scripts/backup.py`, y la restauración de prueba en una base diferente según `docs/05_EVIDENCIAS_Y_PRUEBAS.md`.

## Estructura
- `compose.yaml`: servicios, red y volúmenes persistentes.
- `addons/mypetsfriends_vet/`: módulo veterinario adaptado para Odoo 20.
- `datos/`: CSV ficticios de productos, servicios, propietarios, proveedores, pacientes y citas.
- `scripts/`: preparación, carga, respaldo y validación.
- `docs/`: arquitectura, instalación, uso y procedimientos.
- `evidencias/`: listas para incorporar capturas **reales** verificadas, sin secretos.

## Seguridad
**No publicar** `.env`, `config/odoo.conf`, claves, `.bak` locales, backups reales, volúmenes Docker o capturas que muestren secretos. El archivo `.env.example` solo contiene marcadores de ejemplo.

## Nota de entrega
Esta copia contiene correcciones aplicadas al código fuente original para Odoo 20: definición de accesos, vistas de búsqueda y carga normal del addon. El servidor activo en el equipo del estudiante contiene datos fuera de este ZIP; estos no se transfieren a través del código.
