# 06 · Modelo de informe de prácticas

**Título:** Implementación de ERP para una clínica veterinaria usando Odoo Community, Docker y PostgreSQL.

> Documento modelo para desarrollar con información observada por el equipo. Completar nombres, fechas, resultados y capturas reales. No afirmar que una prueba fue realizada si no existe evidencia.

## 1. Introducción

La clínica veterinaria MyPetsFriends registra información operativa en herramientas separadas, lo que dificulta la consulta del historial de pacientes y el seguimiento comercial. El proyecto plantea un ERP centralizado, portable y basado en herramientas de software libre.

## 2. Objetivo general

Implementar un entorno ERP sobre Odoo Community, PostgreSQL y Docker que permita gestionar pacientes, citas, historial clínico, vacunación, servicios, productos, inventario y facturación de demostración.

### Objetivos específicos

- Preparar entorno Docker y repositorio versionado.
- Diseñar módulos y estructuras de datos para el negocio veterinario.
- Cargar datos de ejemplo mediante CSV.
- Verificar el flujo operativo y comercial.
- Comprobar persistencia y capacidad de respaldo/restauración.

## 3. Tecnologías utilizadas

- Odoo Community 20.0: plataforma ERP y módulos estándar.
- Python: modelo de datos, reglas de negocio y scripts.
- XML: vistas y menús.
- PostgreSQL 16: datos persistentes.
- Docker Compose: despliegue reproducible.
- HTML/CSS: presentación gráfica adaptada del prototipo Mimo.
- Git/GitHub: versionado y entrega.

## 4. Metodología de ejecución

**Preparación.** Instalación de herramientas, comprobación de versiones, organización del repositorio y elección de versión.

**Despliegue.** Configuración de contenedores, variables privadas, inicialización y persistencia de PostgreSQL/Odoo.

**Configuración y desarrollo.** Carga de empresa en PEN y catálogos, implementación de pacientes, agenda, consulta, vacuna y vinculación con Ventas.

**Verificación.** Ejecución de un caso de consulta y venta de un producto, comprobación de inventario, facturación, respaldo y restauración.

## 5. Desarrollo técnico propio

En el módulo `mypetsfriends_vet` se definieron cuatro entidades principales (`vet.pet`, `vet.appointment`, `vet.consultation` y `vet.vaccination`) y una entidad para los productos utilizados. `vet.pet` se relaciona con `res.partner` para evitar duplicar propietarios. Se agregó una verificación de intervalos de atención y una acción que genera un documento de venta estándar desde una cita atendida. Los registros de facturación no se diseñaron aparte; se utiliza el funcionamiento de Odoo para garantizar coherencia con el sistema ERP.

## 6. Caso de uso documentado

Paciente: Luna. Propietaria: Ana Torres. Servicio: Consulta. Producto adicional: Collar ajustable pequeño. Secuencia: crear/confirmar cita, registrar diagnóstico, cerrar atención, generar y confirmar venta, registrar entrega y emitir factura demostrativa. **Insertar aquí capturas y códigos reales de los documentos al terminar el ejercicio.**

## 7. Tabla de resultados

| Prueba | Resultado | Evidencia |
|---|---|---|
| Docker / Compose instalados | Pendiente | Captura 01 |
| Odoo y PostgreSQL activos | Pendiente | Captura 03 |
| 30 productos / 15 propietarios / 5 proveedores | Pendiente | Capturas y CSV |
| Cita y atención Luna | Pendiente | Capturas 08–10 |
| Venta, stock, factura | Pendiente | Capturas 11–16 |
| Persistencia | Pendiente | Captura 18 |
| Backup y restauración | Pendiente | Capturas 19–20 |

## 8. Dificultades técnicas y soluciones

Rellenar después de ejecutar el proyecto. Ejemplos de incidencias que pueden aparecer: motor Docker no iniciado, puerto ocupado, conflicto de credenciales, importación de tipos de producto o ajuste de configuración contable. Cada incidencia debe registrar su error y su solución observada.

## 9. Conclusiones

El diseño modular permite aprovechar las funciones maduras del ERP y concentrar el desarrollo en el proceso veterinario. La portabilidad depende de conservar no solo la configuración Docker sino también los volúmenes o un respaldo verificable. **Completar la conclusión sobre funcionamiento únicamente después de superar las pruebas.**

## 10. Recomendaciones

Consolidar procedimientos de respaldo, definir perfiles de acceso, habilitar HTTPS, revisión de datos personales y evaluar la localización tributaria peruana si se considera uso real.
