# 01 · Arquitectura y requisitos del cliente

## Situación actual y propuesta

MyPetsFriends administra propietarios, historias y ventas en cuadernos y hojas de cálculo. La solución plantea una **base central PostgreSQL** y una aplicación Odoo Community para integrar operación clínica y administrativa. Se desarrolla únicamente el complemento veterinario; Odoo resuelve de forma estándar contactos, ventas, inventario y facturación.

```text
Usuario interno en navegador
        │ http://localhost:8069
        ▼
   Odoo Community 20.0 (contenedor)
     ├─ Módulo MyPetsFriends (desarrollo Python/XML)
     │    ├─ Mascotas y propietarios
     │    ├─ Calendario de citas
     │    ├─ Consultas / historial
     │    └─ Carnet de vacunación
     ├─ Contactos, Ventas, Inventario, Facturación
     └─ Volumen odoo_filestore (archivos/adjuntos)
        │  red privada Docker
        ▼
   PostgreSQL 16 (contenedor)
     └─ Volumen postgres_data (datos estructurados)

   Presentación HTML Mimo adaptada
     └─ Diseño de referencia, independiente del ERP
```

## Matriz de requerimientos

| Requerimiento de la profesora | Implementación propuesta | Evidencia a obtener |
|---|---|---|
| Docker + Compose | Dos servicios con imagen oficial `odoo:20.0` y `postgres:16` | Captura versiones y `docker compose ps` |
| Repositorio GitHub, README | Árbol de archivos y pasos preparados | URL real pendiente de crear |
| Última versión estable | Odoo Community 20.0 (noviembre 2026) | Documento de criterio y `odoo --version` |
| Volúmenes persistentes, `.env` | `postgres_data`, `odoo_filestore` y credenciales privadas generadas | Compose, `.env.example`, recreación |
| Base de datos | `mypetsfriends` creada por script | SQL y pantalla de Odoo |
| Respaldo / restauración | Scripts CLI Odoo, restauración en base distinta | Archivo real y SQL de verificación |
| Empresa, logo, moneda PEN | `seed_odoo.py` | Captura Configuración → Compañías |
| Contactos, Ventas, Inventario, Facturación, Calendario | Dependencias instaladas con el addon | Apps instaladas |
| 30 productos | `datos/productos.csv` | 30 productos con códigos MPF001–MPF030 |
| 15 propietarios | `datos/propietarios.csv` | Contactos cliente |
| 5 proveedores | `datos/proveedores.csv` | Contactos proveedor |
| Consulta, vacunación, baño, cirugía | `datos/servicios.csv` | Servicios SRV001–SRV004 |
| Propietarios y pacientes | Modelo `vet.pet` vinculado a `res.partner` | Fichas de mascotas |
| Citas y consultas | `vet.appointment` y `vet.consultation` | Agenda e historia |
| Carnet de vacunas | Modelo `vet.vaccination` | Registro de fechas y lotes |
| Venta / inventario | Presupuesto sale.order + entrega stock.picking | Pedido y movimiento |
| Facturación | Factura de `account.move` en Odoo | Factura contable de DEMOSTRACIÓN |
| Reportes | Ventas e Inventario nativos Odoo | Capturas o exportaciones reales |

## Decisiones de diseño

1. **No reconstruir Ventas ni Facturación desde cero.** Se integra con modelos existentes para garantizar un flujo ERP consistente.
2. **No usar Supabase en paralelo.** Mimo lo proponía para otro proyecto, pero el requisito aquí es Odoo + PostgreSQL en Docker.
3. **No guardar contraseñas en Git.** Se crean con Python en el primer uso.
4. **Backups completos.** Un simple `pg_dump` no incluiría los adjuntos; se usa el formato ZIP de Odoo, que contempla el filestore.
5. **Primero alcance académico.** La factura interna es demostrativa; SUNAT y datos personales reales exigen un despliegue adicional.
6. **Evitar bloqueo de agenda en uso básico.** El módulo compara horarios confirmados; una clínica de producción necesitaría proteger también carreras simultáneas mediante bloqueo transaccional.

## Alcance excluido de esta versión

Portal público de reservas conectado al ERP, cobro en línea, autenticación para tutores, comprobante electrónico SUNAT, prescripción firmada, alarmas automáticas de vacunación, multiempresa y sincronización con Mimo. Pueden proponerse como fase posterior.
