# 11 · Diagramas de diseño para sustentar el proyecto

Estos diagramas se pueden visualizar directamente en el repositorio GitHub si Markdown admite Mermaid.

## Arquitectura de servicios

```mermaid
flowchart LR
    U[Usuario del equipo] -->|HTTP local 8069| O[Odoo Community 20.0]
    O --> V[Módulo MyPetsFriends]
    O --> N[Módulos comerciales nativos]
    O -->|red privada Docker| P[(PostgreSQL 16)]
    O --> F[(Volumen filestore)]
    P --> D[(Volumen postgres_data)]
    H[Presentación HTML Mimo adaptada] -.->|enlace a interfaz Odoo| O
```

## Entidades clínicas

```mermaid
erDiagram
    RES_PARTNER ||--o{ VET_PET : es_propietario
    VET_PET ||--o{ VET_APPOINTMENT : tiene_citas
    VET_APPOINTMENT ||--o| VET_CONSULTATION : registra
    VET_PET ||--o{ VET_CONSULTATION : historial
    VET_PET ||--o{ VET_VACCINATION : carnet
    VET_CONSULTATION ||--o{ VET_CONSULTATION_ITEM : utiliza_productos
    PRODUCT_PRODUCT ||--o{ VET_CONSULTATION_ITEM : se_utiliza_en
    PRODUCT_PRODUCT ||--o{ VET_APPOINTMENT : servicio_principal
    VET_APPOINTMENT ||--o| SALE_ORDER : produce_venta
    RES_PARTNER ||--o{ SALE_ORDER : compra
    SALE_ORDER ||--o{ ACCOUNT_MOVE : factura
```

## Flujo de un paciente

```mermaid
flowchart TD
    A[Registrar propietario y mascota] --> B[Programar cita]
    B --> C[Confirmar cita]
    C --> D[Abrir consulta]
    D --> E[Diagnóstico y productos usados]
    E --> F{Diagnóstico completo?}
    F -->|No| E
    F -->|Sí| G[Finalizar consulta]
    G --> H[Generar presupuesto de Odoo]
    H --> I[Confirmar venta]
    I --> J[Validar entrega de productos]
    J --> K[Crear y revisar factura]
    K --> L[Reportes de ventas e inventario]
```

## Explicación breve para la sustentación

Se separó la gestión veterinaria del proceso administrativo. Las mascotas son un modelo propio porque Odoo Contactos gestiona personas, no pacientes animales. Las consultas se asocian a citas y mascotas, y los productos utilizados forman líneas que luego pueden venderse. La venta se genera sobre `sale.order`, de manera que Odoo pueda producir entregas y facturas sin duplicar la lógica contable.
