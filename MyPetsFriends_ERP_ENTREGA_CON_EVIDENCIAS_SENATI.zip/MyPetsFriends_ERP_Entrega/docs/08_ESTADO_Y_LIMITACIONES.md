# Estado y limitaciones verificadas

## Verificado con evidencia de la implementación local
- Versiones de Docker y Docker Compose consultadas.
- PostgreSQL en estado `healthy`.
- Descarga de la imagen Odoo 20 y ejecución de la instalación de módulos.
- Mensaje `ERP preparado en http://localhost:8069`.
- Pantalla del ERP abierta con acceso de administrador.

## Aún por acreditar
- Resultado final del script de carga y conteos en Odoo (30 productos, 15 propietarios, 5 proveedores, 4 servicios).
- Empresa, logo y moneda PEN en interfaz y configuraciones.
- Flujo cita, atención, venta, entrega y factura demostrativa.
- Persistencia tras recreación de contenedores (conservando volúmenes).
- Archivo de respaldo y restauración documentada en base de prueba.
- Capturas de reportes de ventas e inventario.
- URL exacta del repositorio GitHub accesible a la profesora.

## Limitaciones
No es una implementación de producción ni incluye certificación de facturación electrónica SUNAT. No publicar credenciales ni registros reales de clientes.
