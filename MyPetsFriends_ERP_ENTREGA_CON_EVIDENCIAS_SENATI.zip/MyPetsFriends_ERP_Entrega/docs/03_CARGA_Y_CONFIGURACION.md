# 03 · Configuración del negocio y archivos CSV

## Datos de prueba incluidos

| Archivo | Filas | Descripción |
|---|---:|---|
| `datos/productos.csv` | 30 | Vacunas 8, desparasitantes 6, alimentos 8, accesorios 5, medicamentos 3 |
| `datos/productos_importacion_odoo.csv` | 30 | Mismas referencias sin columnas auxiliares: para asistente de importación |
| `datos/propietarios.csv` | 15 | Propietarios ficticios con correo de prueba |
| `datos/proveedores.csv` | 5 | Proveedores ficticios |
| `datos/servicios.csv` | 4 | Consulta, vacunación, baño y cirugía con duración |
| `datos/servicios_importacion_odoo.csv` | 4 | Versión lista para mapear campos en Odoo |
| `datos/mascotas.csv` | 20 | Especie, raza, chip, peso y propietario |
| `datos/citas.csv` | 6 | Agenda de prueba (horas locales de Lima) |
| `datos/vacunaciones.csv` | 5 | Vacunas aplicadas, lotes y refuerzos |
| `datos/stock_inicial.csv` | 30 | Cantidades iniciales en el almacén |

**No son registros reales.** Correos terminados en `.example.test` y teléfonos son de demostración.

## Valores de servicios

| Código | Servicio | Precio de ejemplo | Duración |
|---|---|---:|---:|
| SRV001 | Consulta veterinaria | S/ 65 | 30 min |
| SRV002 | Vacunación | S/ 80 | 30 min |
| SRV003 | Baño y aseo | S/ 55 | 60 min |
| SRV004 | Cirugía menor | S/ 450 | 120 min |

Los precios sirven para probar ventas. La configuración tributaria real debe definirse según la empresa; el script no inventa un RUC.

## Importación automática recomendada

Ejecutar `python scripts/load_demo.py`. El script utiliza el ORM de Odoo para crear las categorías que no existen, asociar propietarios con pacientes y cargar el stock. Es la opción que asegura las relaciones para el escenario clínico.

## Importación manual por interfaz (evidencia adicional)

Si la profesora exige mostrar el asistente de **Importar registros**:

1. **Contactos → Lista → Favoritos/Acciones → Importar**: seleccionar `propietarios.csv`, mapear `name`, `email`, `phone`, `street`, `city` con Nombre, Correo, Teléfono, Calle, Ciudad. Repetir con proveedores.
2. **Ventas o Inventario → Productos → Importar**: `productos_importacion_odoo.csv`. Los campos técnicos son `default_code` (Referencia interna), `name`, `type` (Bienes), `is_storable` (Rastrear inventario), `list_price` (Precio venta), `standard_price` (Costo).
3. **Servicios**: `servicios_importacion_odoo.csv`, `type=service`; mapear código, nombre, tipo y precio.
4. **Inventario**: habilitar seguimiento de existencias y mostrar ajuste de cantidades en almacén con `stock_inicial.csv`, o usar el script de carga (el CSV es la fuente de cantidades).

**Importante:** no ejecutar primero importación manual y luego carga automática sin revisar duplicados. La importación de propietarios por interfaz no define por sí sola la clasificación `customer_rank/supplier_rank`; el script sí la asigna. Los CSV de mascotas y vacunación son para modelos propios, que pueden cargarse por el script o por el importador mapeando las relaciones.

## Moneda y empresa

La compañía se llama MyPetsFriends, país Perú y moneda PEN. Se inserta un logo de huella en el registro empresarial. **La dirección real, RUC y datos fiscales deben completarse únicamente si el caso exige una entidad legal identificable**.

## Inventario y facturación

Los 30 bienes se crean con seguimiento de inventario y stock inicial de laboratorio. Al confirmar una venta, Odoo gestiona la entrega; el auxiliar clínico no modifica el stock por su cuenta. La factura se produce en Odoo Facturación, no dentro del módulo veterinario.
