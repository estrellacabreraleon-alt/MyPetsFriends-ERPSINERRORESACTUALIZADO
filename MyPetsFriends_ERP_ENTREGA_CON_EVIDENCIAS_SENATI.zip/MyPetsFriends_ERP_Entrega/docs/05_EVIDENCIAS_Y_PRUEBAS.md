# 05 · Plan de pruebas y evidencias

**Regla:** documentar únicamente resultados observados en Odoo/Docker. Las validaciones de código y las pruebas operacionales tienen alcance diferente. No presentar una prueba estática como si fuera una instalación en funcionamiento.

## Capturas exigidas (obtener en la computadora que ejecute Odoo)

| Nombre sugerido | Captura real que debe guardarse | Etapa |
|---|---|---|
| `01_versiones.png` | Consola: Docker, Compose, Python | 1 |
| `02_github_repositorio.png` | Repositorio creado con README visible y URL | 1 |
| `03_compose_ps.png` | Dos servicios iniciados (`docker compose ps`) | 2 |
| `04_odoo_inicio.png` | Login o menú de Odoo 20 funcionando | 2 |
| `05_empresa_pen.png` | Nombre, logo y moneda PEN en la compañía | 3 |
| `06_apps_instaladas.png` | Contactos, Ventas, Inventario, Facturación, Calendario y MyPetsFriends | 3 |
| `07_mascota_luna.png` | Ficha completa de Luna | 3 |
| `08_cita_creada.png` | Cita nueva o precargada | 3 |
| `09_cita_confirmada.png` | Estado confirmada / calendario | 3 |
| `10_historial_clinico.png` | Registro de consulta con diagnóstico | 3 |
| `11_venta_presupuesto.png` | Presupuesto consulta + collar | 3 |
| `12_venta_confirmada.png` | Pedido confirmado | 3 |
| `13_entrega_inventario.png` | Entrega de collar validada | 3 |
| `14_factura_demo.png` | Factura de demostración en Odoo | 3 |
| `15_reporte_ventas.png` | Reporte de ventas con operación | 3 |
| `16_reporte_inventario.png` | Reporte de stock antes/después | 3 |
| `17_carnet_vacunacion.png` | Vacunas y próximos refuerzos de Luna | 3 |
| `18_persistencia_antes_despues.png` | Misma mascota antes y después de recreación de contenedores | 2 |
| `19_backup_generado.png` | Carpeta backups con ZIP real | 2 |
| `20_restauracion_validada.png` | SQL con conteo de mascotas en base restaurada | 2 |

Guardar archivos PNG/JPG en `evidencias/capturas/` antes de comprimir el ZIP definitivo para la profesora. No incluir credenciales, RUC o datos personales reales visibles en capturas públicas.

## Comprobación de versiones y registros

Ejecutar y guardar salida de forma manual (Linux/macOS) o captura en PowerShell:

```bash
docker --version
docker compose version
docker compose ps
docker compose logs --tail=150 odoo
docker compose logs --tail=100 db
```

Para guardar logs en archivos, en PowerShell o shell:

```bash
docker compose logs --no-color odoo > evidencias/logs/odoo_real.txt
docker compose logs --no-color db > evidencias/logs/postgres_real.txt
```

Estos logs son reales cuando se generan en la computadora con el servicio levantado.

## Prueba P1 · Persistencia al recrear contenedores

1. Registrar (o editar) un dato identificable, por ejemplo nota `Prueba de persistencia A` en una mascota ficticia.
2. Capturar registro y código del paciente.
3. Ejecutar:

   ```bash
   docker compose down
   docker compose up -d
   ```

4. Entrar a Odoo, buscar el paciente y comprobar la nota sin cambio. Tomar captura de antes/después. El resultado debe ser **igual** porque los volúmenes no se eliminan.

**Nunca** añadir `-v` a `down` en esta prueba.

## Prueba P2 · Respaldo integral Odoo

```bash
python scripts/backup.py
```

Verificar que exista un ZIP no vacío en `backups/`, con fecha/hora en el nombre. Se recomienda abrirlo con un descompresor y comprobar que contenga una base de datos y carpetas de adjuntos/filestore propias del formato Odoo.

El ZIP de respaldo contiene registros de la base; no publicarlo si se usaron datos personales reales. Para evaluación académica usar exclusivamente datos ficticios.

## Prueba P3 · Restauración no destructiva

Con el nombre exacto del ZIP realmente creado:

```bash
python scripts/restore_test.py backups/mypetsfriends_20261119_190000.zip
```

El comando anterior es **un ejemplo de sintaxis**, no un archivo que venga generado. La restauración se hace a `mypetsfriends_prueba`. El sistema original continúa en `mypetsfriends`.

Confirmar desde PostgreSQL (usuario por defecto `odoo`):

```bash
docker compose exec -T db psql -U odoo -d mypetsfriends_prueba -c "SELECT COUNT(*) AS mascotas_restauradas FROM vet_pet;"
```

Revisar que el conteo coincida con el original. Como el filtro web está limitado a `mypetsfriends`, la base restaurada se verifica por SQL; **no es un fallo** que no aparezca en el selector web.

## Prueba P4 · Reglas de negocio

| ID | Prueba | Resultado esperado | Estado actual |
|---|---|---|---|
| T01 | Crear propietario y mascota | Mascota vinculada a contacto | Pendiente de ejecutar |
| T02 | Guardar peso negativo | Rechazo de validación | Pendiente de ejecutar |
| T03 | Confirmar cita | Cambia estado a Confirmada | Pendiente de ejecutar |
| T04 | Confirmar citas solapadas de un profesional | Alerta de solapamiento (uso ordinario) | Pendiente de ejecutar |
| T05 | Abrir atención y registrar diagnóstico | Historia vinculada a mascota/cita | Pendiente de ejecutar |
| T06 | Finalizar consulta sin diagnóstico | Rechazo | Pendiente de ejecutar |
| T07 | Guardar vacuna y fecha de refuerzo | Aparece en carnet | Pendiente de ejecutar |
| T08 | Crear venta desde consulta | Servicio + productos en venta Odoo | Pendiente de ejecutar |
| T09 | Confirmar venta y validar entrega | Stock disminuye | Pendiente de ejecutar |
| T10 | Emitir factura de demostración | Documento generado en Facturación | Pendiente de ejecutar |
| T11 | Recrear contenedores | Datos se conservan | Pendiente de ejecutar |
| T12 | Restaurar un ZIP | Base de prueba recuperable | Pendiente de ejecutar |

## Prueba P5 · Tests automatizados del módulo (en Docker)

```bash
docker compose run --rm odoo odoo -d mypetsfriends -u mypetsfriends_vet --test-tags /mypetsfriends_vet --stop-after-init
```

Incluye 5 casos unitarios. **Guardar resultados de logs**; una definición de prueba incluida no es una prueba pasada hasta ejecutarla.

## Evaluación de cumplimiento final

La entrega académica solo puede declararse terminada cuando exista: archivo ZIP del proyecto, enlace al repositorio creado, screenshots de versiones, módulos/datos, flujo comercial, reportes y evidencia real de persistencia y restauración. La verificación estructural previa no reemplaza esas evidencias.
