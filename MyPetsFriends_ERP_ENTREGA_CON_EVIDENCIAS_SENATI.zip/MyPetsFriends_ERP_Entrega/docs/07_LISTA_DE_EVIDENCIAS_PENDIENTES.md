# Capturas y archivos pendientes para la profesora

1. Terminal de `docker --version` y `docker compose version`.
2. `docker compose ps` mostrando Odoo y PostgreSQL saludables.
3. Interfaz ERP iniciada y menús de aplicación veterinaria.
4. Configuración de empresa MyPetsFriends, PEN y logo.
5. Contactos: propietarios (15) y proveedores (5), con filtros/listas.
6. Productos importados (30) y servicios (4) con tarifas.
7. Paciente, cita, atención, historial, vacunas y generación de presupuesto.
8. Venta y factura de prueba, más reportes de ventas e inventario.
9. Persistencia tras recrear contenedores SIN eliminar volúmenes.
10. Respaldo generado y restauración demostrada en base alternativa.
11. URL GitHub accesible, con archivos, README y commits de correcciones.

Protección: ocultar contraseñas, tokens, `.env`, archivos de producción, datos personales reales y pantallas de otros proyectos Docker.
