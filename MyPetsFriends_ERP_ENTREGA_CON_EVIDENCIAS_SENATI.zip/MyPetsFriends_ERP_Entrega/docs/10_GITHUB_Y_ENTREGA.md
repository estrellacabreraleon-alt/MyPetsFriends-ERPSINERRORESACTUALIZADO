# 10 · GitHub y checklist final de entrega

## Crear repositorio desde la carpeta del proyecto

1. Crear un repositorio **vacío** en https://github.com/new llamado `MyPetsFriends-ERP` (sin README inicial).
2. Abrir una terminal en la carpeta que contiene `compose.yaml`.
3. Ejecutar (reemplazar TU-USUARIO y tus datos de Git):

   ```bash
   git init
   git add .
   git commit -m "Implementar ERP veterinario con Odoo Community 20 y Docker"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/MyPetsFriends-ERP.git
   git push -u origin main
   ```

4. Abrir la URL real del repositorio y verificar que `README.md`, `addons/`, `datos/`, `scripts/` y `docs/` estén publicados.

**Nunca publicar** `.env`, `config/odoo.conf`, respaldos reales ni imágenes con información sensible. `.gitignore` ya excluye esos archivos. Si un archivo privado se agregó alguna vez, retirarlo del historial o cambiar contraseñas según corresponda.

## Checklist

- [ ] Repositorio GitHub creado y link registrado.
- [ ] Docker y Docker Compose instalados; capturas de versiones.
- [ ] Odoo 20 y PostgreSQL en contenedores activos.
- [ ] Base de datos `mypetsfriends` creada, idioma/país y PEN verificados.
- [ ] Módulos Contactos, Ventas, Inventario, Facturación, Calendario instalados.
- [ ] Módulo `MyPetsFriends | Gestión Veterinaria` instalado y accesible.
- [ ] Productos (30), propietarios (15), proveedores (5), servicios (4) verificados en Odoo.
- [ ] Luna: cita, consulta, venta + producto, entrega y factura.
- [ ] Capturas de reportes de Ventas e Inventario.
- [ ] Volúmenes persisten tras `docker compose down` + `up -d`.
- [ ] ZIP de respaldo real generado y restaurado a base diferente.
- [ ] Logs, capturas y evidencia final organizados.
- [ ] Informe de prácticas redactado con nombres y pruebas reales.

## Qué enviar a la profesora

- URL real del repositorio GitHub.
- ZIP del proyecto **sin archivos privados**.
- CSV utilizados y código fuente.
- Capturas de funcionamiento, reportes y comandos de persistencia.
- ZIP del respaldo **solo si contiene datos ficticios y es seguro compartirlo**; si hay dudas, entregar constancia de respaldo y demostración de restauración sin exponer datos personales.
- Informe de prácticas con dificultades, solución y resultados propios.

## Recomendación de presentación

Demostrar la secuencia completa en Odoo en vez de enseñar solamente las pantallas de Mimo: la consigna evalúa la implementación ERP, no una maqueta HTML. Mimo se muestra al final como antecedente visual y propuesta de evolución.
