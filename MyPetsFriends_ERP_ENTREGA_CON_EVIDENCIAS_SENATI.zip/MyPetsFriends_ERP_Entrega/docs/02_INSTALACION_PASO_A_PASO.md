# 02 · Instalación paso a paso

## Requisitos mínimos

- Equipo Windows 10/11 con Docker Desktop (WSL 2 recomendado), o Linux/macOS con Docker Engine + plugin Compose.
- Python 3.10+ y terminal (PowerShell, CMD o shell).
- Conexión a internet al instalar por primera vez las imágenes `odoo:20.0` y `postgres:16`.
- Memoria disponible recomendada de 6 GB o más para Docker; la descarga de imágenes puede ocupar varios GB.

## 1. Abrir terminal en la raíz del proyecto

La raíz contiene `compose.yaml`. En Windows se puede abrir la carpeta con el Explorador y usar **Abrir en Terminal**. No hay que ejecutar comandos desde dentro de `addons`.

```bash
docker --version
docker compose version
python --version
```

Guardar capturas de pantalla de esas tres versiones. En Docker Desktop, comprobar que indique Engine running.

## 2. Configurar y desplegar

```bash
python scripts/install.py
```

El script realiza por etapas: crea `.env` con claves aleatorias, crea `config/odoo.conf`, inicia PostgreSQL, crea la base `mypetsfriends` con idioma español/país Perú, instala el módulo `mypetsfriends_vet` (y sus dependencias), e inicia Odoo.

**Advertencia:** guarda el archivo `.env` en un lugar privado. No lo adjuntes al repositorio ni lo envíes a la profesora. La contraseña maestra de base de datos no es necesariamente igual a la del administrador de Odoo.

Si Python no se reconoce en PowerShell, prueba con `py scripts/install.py`.

## 3. Verificar contenedores y módulo

```bash
docker compose ps
docker compose logs --tail=80 odoo
docker compose exec odoo odoo --version
```

Verificar: servicios `db` y `odoo` activos; en los logs sin errores críticos; entrar a `http://localhost:8069` con las credenciales de `.env`; ver en Aplicaciones el módulo **MyPetsFriends | Gestión Veterinaria**.

## 4. Cargar datos ficticios

```bash
python scripts/load_demo.py
```

Se insertan los contactos, 30 bienes, cuatro servicios, 20 mascotas, seis citas, cinco vacunaciones, una consulta histórica y cantidades iniciales. Los datos se cargan por las APIs del ORM de Odoo desde los CSV originales, no por sentencias directas SQL. Repetir la carga evita duplicados pero **puede restablecer el stock de demostración**, por ello no volver a ejecutarla después de empezar las pruebas de ventas.

## 5. Comprobar la información de la clínica

Abrir Odoo → **Ajustes → Usuarios y compañías → Compañías** y revisar `MyPetsFriends`, logo y PEN. Entrar en **Contactos**, **Ventas**, **Inventario**, **Facturación**, **Calendario** y **MyPetsFriends**.

Si la primera carga del catálogo o del país requiere una configuración adicional, seguir la guía de diagnóstico; **registrar el resultado real y el error**, no inventar capturas.

## 6. Apagar y levantar sin perder datos

```bash
docker compose down
docker compose up -d
```

`down` normal elimina contenedores y red, pero conserva volúmenes. Nunca usar `down -v` para una prueba de persistencia: esa variante elimina volúmenes y datos.

## 7. Actualizar solo el módulo durante desarrollo

```bash
docker compose run --rm odoo odoo -d mypetsfriends -u mypetsfriends_vet --stop-after-init
docker compose up -d
```

Para ver errores: `docker compose logs -f odoo`. Salir del seguimiento de logs con Ctrl+C.

## Nota técnica

La ruta de PostgreSQL **no se publica** como puerto accesible desde Windows. Solo Odoo escucha en `127.0.0.1:8069`. Es una configuración de laboratorio local, no un servidor expuesto a internet.
