# 04 · Caso de demostración: Luna

**Objetivo:** mostrar un proceso completo desde una cita hasta una factura creada en Odoo. Los datos son ficticios; el personal deberá tomar capturas reales de cada pantalla.

## Datos de la operación

- Propietaria: **Ana Torres**, `ana.torres@example.test`.
- Paciente: **Luna**, perra mestiza, código de chip `PE-MPF-1001`.
- Fecha de cita de prueba: **3 diciembre 2026**, 10:00 a. m., hora de Lima (si se importa antes de esa fecha).
- Servicio: **Consulta veterinaria**, código `SRV001`, S/ 65.
- Venta adicional sugerida: **Collar ajustable pequeño**, código `MPF023`, S/ 35.
- Subtotal de referencia de esos dos conceptos: **S/ 100 antes del cálculo tributario de Odoo**. No afirmar que es el total final de factura si se aplica IGV.

## Operación en el sistema

1. **Entrar en MyPetsFriends → Pacientes.** Buscar Luna y abrir su ficha. Verificar propietario, especie, peso y carnet de vacunas. Captura `07_mascota_luna.png`.
2. **MyPetsFriends → Agenda.** Buscar la cita de Luna. Si no existe, crearla con el paciente, `Consulta veterinaria`, profesional y horario futuro disponible. Captura `08_cita_creada.png`.
3. Abrir la cita y seleccionar **Confirmar cita**. Verificar el cambio de estado y la aparición en calendario. Captura `09_cita_confirmada.png`.
4. Seleccionar **Abrir atención**. Completar **síntomas**, **diagnóstico** y **tratamiento**. Ejemplo ficticio: *revisión preventiva, paciente clínicamente estable*.
5. En la pestaña **Productos y medicamentos**, agregar `MPF023 — Collar ajustable pequeño`, cantidad 1. Seleccionar **Finalizar atención**. Captura `10_historial_clinico.png`.
6. Regresar a la cita, que ahora dice **Atendida**; seleccionar **Generar venta**. Odoo abrirá un presupuesto con consulta + collar, ligado a Ana Torres. Captura `11_venta_presupuesto.png`.
7. En **Ventas**, revisar las dos líneas y confirmar el presupuesto. Para la venta de un producto con seguimiento, entrar en la orden de entrega y **validar las cantidades realmente entregadas**. Captura `12_venta_confirmada.png` y `13_entrega_inventario.png`.
8. En la venta confirmada, usar **Crear factura**. Elegir facturar las líneas disponibles conforme a la política de producto, abrir borrador y verificar cliente e importes. Si corresponde a la demostración, pulsar **Confirmar/Publicar** la factura después de revisar el diario contable. Captura `14_factura_demo.png`.
9. En **Ventas → Informes** obtener reporte de pedidos/ventas. En **Inventario → Informes** revisar existencias, especialmente el collar `MPF023`, cuya cantidad debe reflejar el movimiento de salida. Capturas `15_reporte_ventas.png`, `16_reporte_inventario.png`.
10. Como evidencia clínica, abrir el **carnet de Luna** y mostrar la vacuna antirrábica y su próximo refuerzo. Captura `17_carnet_vacunacion.png`.

## Comprobación cuantitativa

| Indicador | Antes | Después esperado (si se confirma y entrega 1 collar) |
|---|---|---|
| Cita Luna | Borrador | Atendida |
| Consulta clínica | No registrada | Historia creada, diagnóstico completo |
| Líneas de venta | 0 | 2: consulta y collar |
| Stock MPF023 | 24 | 23 (si no hay otros movimientos) |
| Factura | No existe | Factura demostrativa creada en Odoo |

**No es facturación electrónica SUNAT.** Para emitir comprobantes electrónicos con validez fiscal falta configurar la localización peruana, los datos reales del emisor y los servicios autorizados necesarios.

## Riesgos a comprobar durante la prueba

- El diario de ventas, impuestos y política de facturación de Odoo pueden necesitar activación/configuración local.
- La entrega de producto inventariable debe hacerse en Inventario para que disminuya el stock.
- Si otra prueba ya utilizó la cita de Luna, crear una nueva cita controlada y consignar su código en el informe.
