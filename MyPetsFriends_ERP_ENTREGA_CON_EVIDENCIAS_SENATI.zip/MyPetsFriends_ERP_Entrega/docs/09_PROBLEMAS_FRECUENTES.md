# 09 · Problemas frecuentes

## `docker: command not found` o `docker compose` no existe

Instalar Docker Desktop, reiniciar la terminal y confirmar `docker --version` y `docker compose version`. En Windows habilitar WSL2 si Docker Desktop lo solicita.

## `Cannot connect to the Docker daemon`

Abrir Docker Desktop y esperar a que el motor esté operativo. En Linux confirmar permisos del usuario de Docker. No cambiar permisos con comandos indiscriminados sobre el socket.

## `Bind for 127.0.0.1:8069 failed` o puerto ocupado

Editar `ODOO_PORT=8079` dentro del archivo privado `.env`, reiniciar Odoo y abrir `http://localhost:8079`. El enlace del frontend está fijado al puerto predeterminado 8069 y puede necesitar actualizarse.

## `Module not found: mypetsfriends_vet`

Comprobar que `addons/mypetsfriends_vet/__manifest__.py` exista, que `addons` esté montado en `/mnt/extra-addons`, y revisar `docker compose logs odoo`. Ejecutar de nuevo `python scripts/install.py`.

## Error al inicializar idioma de Perú

Consultar el error exacto y las traducciones disponibles de Odoo 20. Si el entorno no proporciona `es_PE`, realizar la inicialización en `es_ES` y fijar país Perú/PEN después. No afirmar que se instaló el idioma correcto si no ocurrió.

## No puedo ver una base de datos al restaurar

El archivo `config/odoo.conf` restringe `dbfilter` a `mypetsfriends` y oculta el selector. La base `mypetsfriends_prueba` debe comprobarse con `psql` como describe el plan de evidencias.

## Error de acceso a `res.partner`, Ventas, Inventario o Facturación

Confirmar inicio de sesión como administrador de la base y que las aplicaciones/dependencias estén instaladas. La configuración real de privilegios para usuarios internos se hace en Ajustes → Usuarios.

## No se genera factura / aparece "Nothing to Invoice"

Primero confirmar pedido y validar entrega de los bienes si su política de facturación depende de cantidades entregadas. Comprobar diario de ventas y configuración contable (facturación interna de pruebas).

## La moneda muestra dólares y no PEN

Ejecutar `python scripts/load_demo.py` **antes de registrar facturas**; el script configura PEN sobre una empresa inicial. Para una compañía con transacciones reales, no cambiar moneda sin revisión contable.

## El script de demo falla y muestra un traceback

No repetirlo indiscriminadamente. Guardar `docker compose logs --tail=100 odoo` y el error en consola. La carga usa una única transacción; si falló antes de `env.cr.commit()`, el conjunto de cambios debería revertirse.

## ¿Por qué Mimo permite reservas distintas a las de Odoo?

La copia de Mimo en `referencia_mimo` es solo un prototipo local, no sincronizado. El sistema administrativo de este proyecto es únicamente Odoo. No presentar reservas de Mimo como citas creadas en Odoo.
