@echo off
setlocal
cd /d "%~dp0"
echo === INSTALACION MYPETSFRIENDS ERP ===
where py >nul 2>&1
if %errorlevel%==0 (
  py scripts\install.py
) else (
  python scripts\install.py
)
if %errorlevel% neq 0 (
  echo.
  echo Hubo un problema. Abre docs\09_PROBLEMAS_FRECUENTES.md
) else (
  echo.
  echo Cuando termine, ejecuta CARGAR_DATOS_WINDOWS.bat
)
pause
