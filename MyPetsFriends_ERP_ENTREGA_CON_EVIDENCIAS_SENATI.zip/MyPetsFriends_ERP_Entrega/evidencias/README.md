# Evidencias de MyPetsFriends ERP

Proyecto de implementacion de un ERP veterinario con Odoo Community 20.0 y PostgreSQL 16 en Docker.  
Las capturas se organizan segun la etapa a la que corresponden y describen QUE DEMUESTRAN.  
No son evidencias concluyentes de funciones que no aparecen en ellas.  
  
PRINCIPALES EVIDENCIAS: 07 (despliegue funcionando), 09 (acceso a Odoo), 13 (contenedores activos) y 15 (modelos veterinarios registrados).  
  

### 01. 01 Docker compose y espacio inicial

![01_Docker_compose_y_espacio_inicial](capturas/01_ENTORNO/01_Docker_compose_y_espacio_inicial.png)

Diagnóstico inicial: comandos de Docker Compose, imágenes y espacio en disco. Sirve como evidencia del entorno, no de la instalación completa.

### 02. 02 Descarga imagen Odoo

![02_Descarga_imagen_Odoo](capturas/02_DESPLIEGUE/02_Descarga_imagen_Odoo.png)

Se observa descarga de capas de Odoo en Docker; evidencia del proceso de instalación.

### 03. 03 Imagen Odoo descargada y PostgreSQL

![03_Imagen_Odoo_descargada_y_PostgreSQL](capturas/02_DESPLIEGUE/03_Imagen_Odoo_descargada_y_PostgreSQL.png)

La consola muestra que la imagen de Odoo aparece disponible y PostgreSQL permanece en funcionamiento.

### 04. 04 Contenedores y modulos en inicializacion

![04_Contenedores_y_modulos_en_inicializacion](capturas/02_DESPLIEGUE/04_Contenedores_y_modulos_en_inicializacion.png)

Docker Desktop y registros de Odoo durante inicialización; etapa previa al arranque final.

### 05. 05 Diagnostico permisos del modulo

![05_Diagnostico_permisos_del_modulo](capturas/05_INCIDENCIAS_RESUELTAS/05_Diagnostico_permisos_del_modulo.png)

Incidencia de compatibilidad en el módulo veterinario durante la instalación; se corrigió posteriormente.

### 06. 06 Diagnostico vista XML

![06_Diagnostico_vista_XML](capturas/05_INCIDENCIAS_RESUELTAS/06_Diagnostico_vista_XML.png)

Error de definición de vista XML en Odoo; se aplicaron correcciones y el sistema arrancó después.

### 07. 07 Despliegue exitoso Odoo PostgreSQL

![07_Despliegue_exitoso_Odoo_PostgreSQL](capturas/02_DESPLIEGUE/07_Despliegue_exitoso_Odoo_PostgreSQL.png)

Evidencia principal: 73 módulos cargados, PostgreSQL saludable, contenedor Odoo iniciado y mensaje ERP preparado en localhost:8069.

### 08. 08 Pantalla de inicio sesion

![08_Pantalla_de_inicio_sesion](capturas/03_ACCESO/08_Pantalla_de_inicio_sesion.png)

Pantalla de inicio de sesión de Odoo en localhost:8069, antes del acceso del administrador.

### 09. 09 Acceso autenticado OdooBot

![09_Acceso_autenticado_OdooBot](capturas/03_ACCESO/09_Acceso_autenticado_OdooBot.png)

Sesión iniciada correctamente en Odoo; aparece el chat de OdooBot. No valida por sí sola los datos veterinarios.

### 10. 10 Issue entrega anterior

![10_Issue_entrega_anterior](capturas/06_GITHUB/10_Issue_entrega_anterior.png)

Issue de GitHub relativo a la entrega inicial y el incidente de Docker. Es evidencia de comunicación, no de que el repositorio esté actualizado.

### 11. 11 Proceso de carga CSV iniciado

![11_Proceso_de_carga_CSV_iniciado](capturas/04_DATOS/11_Proceso_de_carga_CSV_iniciado.png)

Ejecución de CARGAR_DATOS_WINDOWS.bat: aparecen los módulos y la carga de datos en curso; falta confirmación final.

### 12. 12 Carga CSV en proceso

![12_Carga_CSV_en_proceso](capturas/04_DATOS/12_Carga_CSV_en_proceso.png)

Registros del cargador Odoo. No se ve el mensaje final de datos guardados.

### 13. 13 Contenedores activos

![13_Contenedores_activos](capturas/02_DESPLIEGUE/13_Contenedores_activos.png)

Comprobación docker ps: Odoo 20.0 y PostgreSQL 16 están activos; la base de datos figura healthy.

### 14. 14 Carga aun sin confirmacion final

![14_Carga_aun_sin_confirmacion_final](capturas/04_DATOS/14_Carga_aun_sin_confirmacion_final.png)

Captura del proceso de importación en PowerShell; aún no confirma inserción de registros.

### 15. 15 Cinco modelos veterinarios registrados

![15_Cinco_modelos_veterinarios_registrados](capturas/03_ACCESO/15_Cinco_modelos_veterinarios_registrados.png)

Consulta SQL de solo lectura: Odoo tiene registrados los modelos vet.pet, vet.appointment, vet.consultation, vet.consultation.item y vet.vaccination. Los valores 1 corresponden a definiciones de modelos, no a cantidad de mascotas o citas.

## Evidencias faltantes



PENDIENTE DE DOCUMENTAR CON CAPTURAS REALES
- Resultado final del script de importacion: mensaje de datos guardados y conteos verificables.
- Listas de 30 productos, 15 propietarios y 5 proveedores efectivamente importados.
- Empresa configurada (logo, PEN), servicios con precios y modulos de negocio.
- Flujo funcional: cita -> atencion -> venta -> factura.
- Reportes de ventas e inventario.
- Prueba de persistencia tras recrear contenedores sin borrar volumenes.
- Respaldo y restauracion de la base de datos en entorno de prueba.
- URL exacta del repositorio y commit de entrega actualizado.

SEGURIDAD Y ALCANCE
- El paquete NO contiene el archivo privado .env ni los secretos reales.
- El archivo .env.example solo tiene valores de ejemplo: NO son contrasenas validas.
- No se incluyen capturas de limpieza de archivos personales ni de credenciales privadas.
- No afirmar que los CSV estan importados hasta obtener verificacion de registros.
- No incluir backups con informacion privada en un repositorio publico.

