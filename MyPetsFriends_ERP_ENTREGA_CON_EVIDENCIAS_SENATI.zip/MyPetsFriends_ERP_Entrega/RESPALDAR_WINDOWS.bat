@echo off
setlocal
cd /d "%~dp0"
echo === RESPALDO ODOO MYPETSFRIENDS ===
where py >nul 2>&1
if %errorlevel%==0 (
  py scripts\backup.py
) else (
  python scripts\backup.py
)
echo.
echo Revisar carpeta backups
pause
