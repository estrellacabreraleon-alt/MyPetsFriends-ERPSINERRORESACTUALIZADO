{
    'name': 'MyPetsFriends | Gestión Veterinaria',
    'summary': 'Pacientes, agenda, consultas, vacunas y ventas vinculadas a Odoo',
    'version': '20.0.1.0.0',
    'category': 'Services',
    'author': 'Equipo de prácticas TI - MyPetsFriends',
    'license': 'LGPL-3',
    'depends': [
        'base', 'contacts', 'calendar', 'sale_management', 'stock', 'account',
    ],
    'data': [
        'security/ir.access.csv',
        'data/sequence.xml',
        'views/pet_views.xml',
        'views/appointment_views.xml',
        'views/consultation_views.xml',
        'views/vaccination_views.xml',
        'views/menus.xml',
    ],
    'application': True,
    'installable': True,
    'auto_install': False,
}
