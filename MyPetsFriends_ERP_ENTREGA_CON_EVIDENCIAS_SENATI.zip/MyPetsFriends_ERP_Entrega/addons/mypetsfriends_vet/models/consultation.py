"""Historia clínica y consumo de productos durante una atención."""
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class VetConsultation(models.Model):
    _name = 'vet.consultation'
    _description = 'Atención / Historia clínica'
    _order = 'date desc, id desc'

    name = fields.Char('Código', default='Nuevo', required=True, copy=False, readonly=True)
    appointment_id = fields.Many2one('vet.appointment', string='Cita', required=True,
                                      ondelete='restrict', index=True)
    pet_id = fields.Many2one('vet.pet', string='Paciente', required=True, ondelete='restrict')
    owner_id = fields.Many2one('res.partner', string='Propietario',
                               related='pet_id.owner_id', store=True, readonly=True)
    vet_id = fields.Many2one('res.users', string='Profesional', required=True,
                             default=lambda self: self.env.user)
    date = fields.Datetime('Fecha de atención', default=fields.Datetime.now, required=True)
    reason = fields.Text('Motivo de consulta')
    symptoms = fields.Text('Síntomas y examen físico')
    temperature_c = fields.Float('Temperatura (°C)', digits=(5, 2))
    weight_kg = fields.Float('Peso de atención (kg)', digits=(8, 2))
    diagnosis = fields.Text('Diagnóstico')
    treatment = fields.Text('Tratamiento / procedimientos')
    recommendations = fields.Text('Indicaciones y seguimiento')
    line_ids = fields.One2many('vet.consultation.item', 'consultation_id',
                                string='Productos usados / vendidos')
    state = fields.Selection([('draft', 'En atención'), ('done', 'Finalizada')],
                              default='draft', required=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'Nuevo') == 'Nuevo':
                vals['name'] = self.env['ir.sequence'].next_by_code('vet.consultation') or 'Nuevo'
        return super().create(vals_list)

    @api.constrains('appointment_id', 'pet_id')
    def _check_consultation_appointment(self):
        for rec in self:
            if rec.appointment_id.pet_id != rec.pet_id:
                raise ValidationError(_('La mascota debe corresponder a la cita.'))
            if self.search_count([('appointment_id', '=', rec.appointment_id.id), ('id', '!=', rec.id)]):
                raise ValidationError(_('Una cita solo puede tener una consulta.'))

    def action_finish(self):
        for rec in self:
            if not rec.diagnosis:
                raise UserError(_('Ingrese el diagnóstico antes de finalizar.'))
            rec.write({'state': 'done'})
            rec.appointment_id.write({'state': 'done', 'consultation_id': rec.id})
            if rec.weight_kg > 0:
                rec.pet_id.weight_kg = rec.weight_kg


class VetConsultationItem(models.Model):
    _name = 'vet.consultation.item'
    _description = 'Producto de atención veterinaria'

    consultation_id = fields.Many2one('vet.consultation', string='Consulta',
                                      required=True, ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Producto / medicamento',
                                  required=True, domain=[('type', '=', 'consu')])
    quantity = fields.Float('Cantidad', default=1.0, required=True)
    notes = fields.Char('Indicaciones')

    @api.constrains('quantity', 'product_id')
    def _check_item(self):
        for rec in self:
            if rec.quantity <= 0:
                raise ValidationError(_('La cantidad debe ser mayor que cero.'))
            if rec.product_id.type != 'consu':
                raise ValidationError(_('Seleccione un producto, no un servicio.'))
