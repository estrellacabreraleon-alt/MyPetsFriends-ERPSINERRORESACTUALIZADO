"""Paciente veterinario: cada mascota pertenece a un contacto de Odoo."""
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class VetPet(models.Model):
    _name = 'vet.pet'
    _description = 'Paciente veterinario'
    _order = 'name'

    name = fields.Char('Nombre de la mascota', required=True, index=True)
    owner_id = fields.Many2one('res.partner', string='Propietario', required=True,
                                ondelete='restrict', index=True)
    species = fields.Selection([
        ('dog', 'Perro'), ('cat', 'Gato'), ('bird', 'Ave'),
        ('rabbit', 'Conejo'), ('other', 'Otro'),
    ], string='Especie', required=True, default='dog')
    breed = fields.Char('Raza')
    sex = fields.Selection([('male', 'Macho'), ('female', 'Hembra')], string='Sexo')
    birth_date = fields.Date('Nacimiento')
    color = fields.Char('Color')
    chip = fields.Char('Microchip', copy=False, index=True)
    weight_kg = fields.Float('Peso (kg)', digits=(8, 2))
    allergies = fields.Text('Alergias / alertas')
    notes = fields.Text('Notas generales')
    active = fields.Boolean(default=True)
    appointment_ids = fields.One2many('vet.appointment', 'pet_id', string='Citas')
    consultation_ids = fields.One2many('vet.consultation', 'pet_id', string='Historial clínico')
    vaccination_ids = fields.One2many('vet.vaccination', 'pet_id', string='Vacunación')
    appointment_count = fields.Integer(compute='_compute_counters', string='Citas')
    consultation_count = fields.Integer(compute='_compute_counters', string='Consultas')

    @api.depends('appointment_ids', 'consultation_ids')
    def _compute_counters(self):
        for pet in self:
            pet.appointment_count = len(pet.appointment_ids)
            pet.consultation_count = len(pet.consultation_ids)

    @api.constrains('weight_kg', 'birth_date', 'chip')
    def _check_pet(self):
        for pet in self:
            if pet.weight_kg < 0:
                raise ValidationError(_('El peso no puede ser negativo.'))
            if pet.birth_date and pet.birth_date > fields.Date.today():
                raise ValidationError(_('La fecha de nacimiento no puede ser futura.'))
            if pet.chip and self.search_count([('chip', '=', pet.chip), ('id', '!=', pet.id)]):
                raise ValidationError(_('Este número de microchip ya está registrado.'))

    def action_view_appointments(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': _('Citas de %s') % self.name,
            'res_model': 'vet.appointment', 'view_mode': 'list,form,calendar',
            'domain': [('pet_id', '=', self.id)],
            'context': {'default_pet_id': self.id},
        }

    def action_view_consultations(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': _('Historial de %s') % self.name,
            'res_model': 'vet.consultation', 'view_mode': 'list,form',
            'domain': [('pet_id', '=', self.id)],
        }
