"""Carnet de vacunación y fechas de refuerzo por paciente."""
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class VetVaccination(models.Model):
    _name = 'vet.vaccination'
    _description = 'Vacuna aplicada'
    _order = 'date desc, id desc'
    _rec_name = 'vaccine_name'

    pet_id = fields.Many2one('vet.pet', string='Mascota', required=True,
                              ondelete='restrict', index=True)
    owner_id = fields.Many2one('res.partner', string='Propietario',
                               related='pet_id.owner_id', store=True, readonly=True)
    vaccine_name = fields.Char('Vacuna', required=True)
    product_id = fields.Many2one('product.product', string='Producto comercial',
                                  domain=[('type', '=', 'consu')])
    date = fields.Date('Fecha de aplicación', required=True, default=fields.Date.today)
    next_date = fields.Date('Próxima dosis / refuerzo')
    batch = fields.Char('Lote del medicamento')
    professional_id = fields.Many2one('res.users', string='Aplicada por',
                                      default=lambda self: self.env.user)
    observation = fields.Text('Observaciones')

    @api.constrains('date', 'next_date')
    def _check_dates(self):
        for rec in self:
            if rec.next_date and rec.date and rec.next_date < rec.date:
                raise ValidationError(_('La fecha del refuerzo no puede anteceder a la vacunación.'))
