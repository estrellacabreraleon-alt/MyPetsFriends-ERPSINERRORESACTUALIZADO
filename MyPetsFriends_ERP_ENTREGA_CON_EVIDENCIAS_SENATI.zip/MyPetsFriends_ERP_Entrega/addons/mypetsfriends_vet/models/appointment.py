"""Agenda conectada con consultas y ventas reales de Odoo.

No se implementan cobros ni facturas paralelas: se usan sale.order y account.move.
"""
from datetime import timedelta
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class VetAppointment(models.Model):
    _name = 'vet.appointment'
    _description = 'Cita veterinaria'
    _order = 'scheduled_at desc, id desc'

    name = fields.Char('Código', required=True, default='Nuevo', readonly=True, copy=False)
    pet_id = fields.Many2one('vet.pet', string='Mascota', required=True, ondelete='restrict', index=True)
    owner_id = fields.Many2one('res.partner', string='Propietario',
                               related='pet_id.owner_id', store=True, readonly=True)
    vet_id = fields.Many2one('res.users', string='Profesional', required=True,
                             default=lambda self: self.env.user, index=True)
    service_id = fields.Many2one('product.product', string='Servicio principal', required=True,
                                  domain=[('type', '=', 'service')])
    scheduled_at = fields.Datetime('Inicio programado', required=True, index=True)
    duration_minutes = fields.Integer('Duración (min)', default=30, required=True)
    ends_at = fields.Datetime('Fin programado', compute='_compute_ends_at', store=True)
    reason = fields.Text('Motivo / observaciones')
    state = fields.Selection([
        ('draft', 'Borrador'), ('confirmed', 'Confirmada'),
        ('in_progress', 'En atención'), ('done', 'Atendida'),
        ('cancelled', 'Cancelada'),
    ], string='Estado', default='draft', required=True)
    consultation_id = fields.Many2one('vet.consultation', string='Consulta', readonly=True, copy=False)
    sale_order_id = fields.Many2one('sale.order', string='Venta asociada', readonly=True, copy=False)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'Nuevo') == 'Nuevo':
                vals['name'] = self.env['ir.sequence'].next_by_code('vet.appointment') or 'Nuevo'
        return super().create(vals_list)

    @api.depends('scheduled_at', 'duration_minutes')
    def _compute_ends_at(self):
        for rec in self:
            rec.ends_at = (rec.scheduled_at + timedelta(minutes=rec.duration_minutes)
                           if rec.scheduled_at and rec.duration_minutes > 0 else False)

    @api.constrains('duration_minutes', 'service_id')
    def _check_basics(self):
        for rec in self:
            if rec.duration_minutes <= 0 or rec.duration_minutes > 480:
                raise ValidationError(_('La duración debe estar entre 1 y 480 minutos.'))
            if rec.service_id and rec.service_id.type != 'service':
                raise ValidationError(_('Debe seleccionar un producto de tipo Servicio.'))

    @api.constrains('scheduled_at', 'duration_minutes', 'vet_id', 'state')
    def _check_schedule(self):
        # Rechaza cruces ordinarios. No sustituye un sistema de bloqueo transaccional
        # para concurrencia masiva; alcance educativo de una clínica pequeña.
        for rec in self:
            if rec.state not in ('confirmed', 'in_progress', 'done') or not rec.ends_at:
                continue
            conflict = self.search_count([
                ('id', '!=', rec.id), ('vet_id', '=', rec.vet_id.id),
                ('state', 'in', ('confirmed', 'in_progress', 'done')),
                ('scheduled_at', '<', rec.ends_at), ('ends_at', '>', rec.scheduled_at),
            ])
            if conflict:
                raise ValidationError(_('El profesional tiene otra cita en ese horario.'))

    def action_confirm(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('Solo pueden confirmarse citas en borrador.'))
            rec.state = 'confirmed'

    def action_cancel(self):
        for rec in self:
            if rec.state == 'done':
                raise UserError(_('Una atención finalizada no puede cancelarse.'))
            rec.state = 'cancelled'

    def action_open_consultation(self):
        self.ensure_one()
        if self.state not in ('confirmed', 'in_progress', 'done'):
            raise UserError(_('Confirme la cita antes de iniciar la atención.'))
        consultation = self.consultation_id
        if not consultation:
            consultation = self.env['vet.consultation'].create({
                'appointment_id': self.id,
                'pet_id': self.pet_id.id,
                'vet_id': self.vet_id.id,
                'reason': self.reason or '',
            })
            self.consultation_id = consultation.id
            if self.state == 'confirmed':
                self.state = 'in_progress'
        return {
            'type': 'ir.actions.act_window', 'res_model': 'vet.consultation',
            'res_id': consultation.id, 'view_mode': 'form',
            'name': _('Atención veterinaria'), 'target': 'current',
        }

    def action_create_sale_order(self):
        """Crea presupuesto Odoo: un servicio + productos registrados en consulta.

        Confirmar venta, validar entrega e emitir factura se hace en pantallas nativas.
        """
        self.ensure_one()
        if self.sale_order_id:
            return self.action_view_sale_order()
        if self.state != 'done' or not self.consultation_id or self.consultation_id.state != 'done':
            raise UserError(_('Primero finalice la consulta clínica.'))
        lines = [(0, 0, {
            'product_id': self.service_id.id,
            'product_uom_qty': 1,
            'price_unit': self.service_id.lst_price,
            'name': f'{self.service_id.display_name} | Paciente: {self.pet_id.name}',
        })]
        for item in self.consultation_id.line_ids:
            lines.append((0, 0, {
                'product_id': item.product_id.id,
                'product_uom_qty': item.quantity,
                'price_unit': item.product_id.lst_price,
                'name': item.product_id.display_name,
            }))
        order_values = {
            'partner_id': self.owner_id.id,
            'origin': self.name,
            'client_order_ref': self.pet_id.name,
            'order_line': lines,
        }
        # En el caso peruano el presupuesto debe usar una tarifa en PEN.
        pricelist = self.env['product.pricelist'].search([
            ('currency_id', '=', self.env.company.currency_id.id),
            ('company_id', 'in', [False, self.env.company.id]),
        ], limit=1)
        if pricelist:
            order_values['pricelist_id'] = pricelist.id
        order = self.env['sale.order'].create(order_values)
        self.sale_order_id = order.id
        return self.action_view_sale_order()

    def action_view_sale_order(self):
        self.ensure_one()
        if not self.sale_order_id:
            raise UserError(_('Aún no se ha generado una venta.'))
        return {
            'type': 'ir.actions.act_window', 'name': _('Venta vinculada'),
            'res_model': 'sale.order', 'view_mode': 'form',
            'res_id': self.sale_order_id.id,
        }
