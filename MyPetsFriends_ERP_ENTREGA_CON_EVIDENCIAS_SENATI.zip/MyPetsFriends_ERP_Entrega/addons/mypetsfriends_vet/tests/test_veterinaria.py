"""Pruebas unitarias de reglas clínicas y vínculo al flujo de venta Odoo.

Se ejecutan CON Odoo instalado (no con Python solo):
docker compose run --rm odoo odoo -d mypetsfriends -u mypetsfriends_vet \
  --test-tags /mypetsfriends_vet --stop-after-init
"""
from datetime import timedelta
from odoo import fields
from odoo.exceptions import ValidationError, UserError
from odoo.tests.common import TransactionCase


class TestVeterinaria(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.owner = cls.env['res.partner'].create({'name': 'Cliente prueba QA', 'email': 'qa@example.test'})
        cls.pet = cls.env['vet.pet'].create({
            'name': 'Luna QA', 'owner_id': cls.owner.id,
            'species': 'dog', 'weight_kg': 9.3,
        })
        cls.service = cls.env['product.product'].create({
            'name': 'Consulta QA', 'type': 'service', 'list_price': 65,
        })
        cls.good = cls.env['product.product'].create({
            'name': 'Collar QA', 'type': 'consu', 'list_price': 35,
        })
        cls.start = fields.Datetime.now() + timedelta(days=25)

    def new_appointment(self, offset=0):
        return self.env['vet.appointment'].create({
            'pet_id': self.pet.id, 'service_id': self.service.id,
            'vet_id': self.env.user.id,
            'scheduled_at': self.start + timedelta(minutes=offset),
            'duration_minutes': 30,
        })

    def test_01_paciente_vinculado_propietario(self):
        self.assertEqual(self.pet.owner_id, self.owner)
        with self.assertRaises(ValidationError):
            self.pet.write({'weight_kg': -5})

    def test_02_no_solapar_citas_confirmadas(self):
        first = self.new_appointment()
        first.action_confirm()
        second = self.new_appointment(offset=15)
        with self.assertRaises(ValidationError):
            second.action_confirm()

    def test_03_consulta_genera_presupuesto(self):
        appointment = self.new_appointment(offset=90)
        appointment.action_confirm()
        appointment.action_open_consultation()
        clinical = appointment.consultation_id
        clinical.write({'diagnosis': 'Sin alteraciones', 'treatment': 'Control preventivo'})
        self.env['vet.consultation.item'].create({
            'consultation_id': clinical.id, 'product_id': self.good.id, 'quantity': 1,
        })
        clinical.action_finish()
        self.assertEqual(appointment.state, 'done')
        appointment.action_create_sale_order()
        self.assertEqual(len(appointment.sale_order_id.order_line), 2)
        self.assertEqual(appointment.sale_order_id.partner_id, self.owner)

    def test_04_diagnostico_obligatorio_al_finalizar(self):
        appointment = self.new_appointment(offset=180)
        appointment.action_confirm()
        appointment.action_open_consultation()
        with self.assertRaises(UserError):
            appointment.consultation_id.action_finish()

    def test_05_vacunas_refuerzos_validos(self):
        vaccination = self.env['vet.vaccination'].create({
            'pet_id': self.pet.id, 'vaccine_name': 'Rabia',
            'date': '2026-10-01', 'next_date': '2027-10-01',
        })
        self.assertEqual(vaccination.pet_id, self.pet)
        with self.assertRaises(ValidationError):
            vaccination.write({'next_date': '2026-09-01'})
