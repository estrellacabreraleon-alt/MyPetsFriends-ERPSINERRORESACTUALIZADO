@echo off
setlocal
cd /d "%~dp0"
echo === CARGA DATOS FICTICIOS MYPETSFRIENDS ===
where py >nul 2>&1
if %errorlevel%==0 (
  py scripts\load_demo.py
) else (
  python scripts\load_demo.py
)
echo.
echo Para consultar el ERP: http://localhost:8069
pause
