"""Ejecuta un script dentro de `odoo shell` y confirma cambios de forma explícita."""
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import read_env

ROOT = Path(__file__).resolve().parents[1]


def main():
    env = read_env(ROOT / '.env')
    db = env['ODOO_DB']
    cmd = ['docker','compose','exec','-T','odoo','odoo','shell','-d',db,'--shell-file','/mnt/project-scripts/seed_odoo.py']
    print('Importando CSV y creando datos de prueba en Odoo...')
    subprocess.run(cmd, cwd=ROOT, check=True)
    print('Carga finalizada. Verifique el ERP y el resumen de la consola.')


if __name__ == '__main__':
    main()
