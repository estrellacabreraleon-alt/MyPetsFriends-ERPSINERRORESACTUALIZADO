"""Preparación LOCAL. No requiere librerías ni cuentas externas.

Crea .env y config/odoo.conf ignorados por Git. Las claves no están dentro del ZIP.
Puede volver a ejecutarse: conserva secretos existentes.
"""
from pathlib import Path
from secrets import token_urlsafe

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / '.env'
CONF_FILE = ROOT / 'config' / 'odoo.conf'


def read_env(path):
    values = {}
    if path.exists():
        for line in path.read_text(encoding='utf-8').splitlines():
            if line.strip() and not line.lstrip().startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                values[k.strip()] = v.strip().strip('"').strip("'")
    return values


def main():
    current = read_env(ENV_FILE)
    values = {
        'ODOO_VERSION': current.get('ODOO_VERSION', '20.0'),
        'ODOO_PORT': current.get('ODOO_PORT', '8069'),
        'ODOO_DB': current.get('ODOO_DB', 'mypetsfriends'),
        'POSTGRES_USER': current.get('POSTGRES_USER', 'odoo'),
        'POSTGRES_PASSWORD': current.get('POSTGRES_PASSWORD') or token_urlsafe(28),
        'ODOO_MASTER_PASSWORD': current.get('ODOO_MASTER_PASSWORD') or token_urlsafe(28),
        'ODOO_ADMIN_LOGIN': current.get('ODOO_ADMIN_LOGIN', 'admin'),
        'ODOO_ADMIN_PASSWORD': current.get('ODOO_ADMIN_PASSWORD') or token_urlsafe(20),
    }
    for key in ('ODOO_DB', 'POSTGRES_USER'):
        if not values[key].replace('_', '').isalnum():
            raise ValueError(f'{key}: usar solo letras, números y guiones bajos')
    if not ENV_FILE.exists():
        ENV_FILE.write_text('# Datos privados - no subir a GitHub\n' + ''.join(f'{k}={v}\n' for k, v in values.items()), encoding='utf-8')
        ENV_FILE.chmod(0o600)
        print('Creado .env con contraseñas aleatorias locales')
    else:
        print('Se conserva .env existente')
    # Regenera solo si no existe. Nunca pisar una contraseña maestra en uso.
    if not CONF_FILE.exists():
        CONF_FILE.parent.mkdir(parents=True, exist_ok=True)
        CONF_FILE.write_text(
            '[options]\n'
            'addons_path = /mnt/extra-addons\n'
            'data_dir = /var/lib/odoo\n'
            'http_interface = 0.0.0.0\n'
            f'admin_passwd = {values["ODOO_MASTER_PASSWORD"]}\n'
            f'dbfilter = ^{values["ODOO_DB"]}$\n'
            'list_db = False\n'
            'log_level = info\n'
            'workers = 0\n', encoding='utf-8')
        CONF_FILE.chmod(0o600)
        print('Creado config/odoo.conf con contraseña maestra protegida')
    else:
        print('Se conserva config/odoo.conf existente')
    print('Preparación terminada. Próximo paso: python scripts/install.py')


if __name__ == '__main__':
    main()
