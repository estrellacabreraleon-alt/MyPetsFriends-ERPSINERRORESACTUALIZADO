"""Verificación estática reproducible, con biblioteca estándar Python.

NO simula la instalación ni certifica que Docker, Odoo o facturación funcionen.
"""
from pathlib import Path
import ast
import compileall
import csv
import datetime
from zoneinfo import ZoneInfo
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []
GOOD = []


def check(test, label):
    (GOOD if test else ERRORS).append(label)


def main():
    must_exist = [
        'compose.yaml', '.env.example', 'README.md', '.gitignore',
        'scripts/install.py', 'scripts/prepare.py', 'scripts/load_demo.py',
        'scripts/backup.py', 'scripts/restore_test.py', 'scripts/seed_odoo.py',
        'addons/mypetsfriends_vet/__manifest__.py',
        'addons/mypetsfriends_vet/views/pet_views.xml',
        'addons/mypetsfriends_vet/views/appointment_views.xml',
        'addons/mypetsfriends_vet/views/consultation_views.xml',
        'addons/mypetsfriends_vet/views/vaccination_views.xml',
        'addons/mypetsfriends_vet/security/ir.model.access.csv',
        'presentacion/index.html',
    ]
    for name in must_exist:
        check((ROOT / name).is_file(), 'Existe ' + name)
    manifest = ast.literal_eval((ROOT / 'addons/mypetsfriends_vet/__manifest__.py').read_text(encoding='utf-8'))
    check(manifest.get('version', '').startswith('20.0'), 'Módulo destinado a Odoo 20')
    for name in manifest['data']:
        check((ROOT / 'addons/mypetsfriends_vet' / name).is_file(), 'Manifest referencia ' + name)

    for file in (ROOT / 'addons/mypetsfriends_vet').rglob('*.xml'):
        try:
            ET.parse(file)
            GOOD.append('XML válido: ' + str(file.relative_to(ROOT)))
        except ET.ParseError as exc:
            ERRORS.append(f'XML inválido: {file}: {exc}')
    check(compileall.compile_dir(str(ROOT / 'addons'), quiet=1), 'Python de módulo compila')
    check(compileall.compile_dir(str(ROOT / 'scripts'), quiet=1), 'Python de scripts compila')

    for name, count in {
        'productos.csv':30, 'propietarios.csv':15, 'proveedores.csv':5,
        'servicios.csv':4, 'mascotas.csv':20, 'citas.csv':6,
        'vacunaciones.csv':5, 'stock_inicial.csv':30,
        'productos_importacion_odoo.csv':30, 'servicios_importacion_odoo.csv':4,
    }.items():
        with (ROOT / 'datos' / name).open(encoding='utf-8-sig', newline='') as f:
            result = list(csv.DictReader(f))
        check(len(result) == count, f'CSV {name}: {len(result)} filas (esperadas {count})')

    compose = (ROOT / 'compose.yaml').read_text(encoding='utf-8')
    for spec in ['postgres:16', 'odoo:${ODOO_VERSION', 'postgres_data:',
                 'odoo_filestore:', 'condition: service_healthy', './datos:/mnt/demo-data:ro']:
        check(spec in compose, f'Compose contiene {spec}')
    try:
        import yaml
        yaml.safe_load(compose)
        GOOD.append('Sintaxis YAML parseada (PyYAML disponible)')
    except ImportError:
        GOOD.append('Análisis YAML completo omitido (PyYAML no instalado)')
    except Exception as exc:
        ERRORS.append(f'YAML inválido: {exc}')

    lines = [
        'VALIDACIÓN ESTÁTICA DEL CÓDIGO - MyPetsFriends',
        'Fecha: ' + datetime.datetime.now(ZoneInfo('America/Lima')).isoformat(timespec='seconds'),
        'IMPORTANTE: ESTA PRUEBA NO EJECUTA DOCKER / ODOO / POSTGRESQL.',
        '',
        f'OK: {len(GOOD)} | ERRORES: {len(ERRORS)}',
        '',
        *(f'[OK] {x}' for x in GOOD),
        *(f'[ERROR] {x}' for x in ERRORS),
    ]
    result = ROOT / 'evidencias/VALIDACION_ESTATICA.txt'
    result.parent.mkdir(exist_ok=True)
    result.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    if ERRORS:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
