"""Carga de demostración repetible para Odoo 20 Community.

Se ejecuta DENTRO de Odoo:
    odoo shell -d mypetsfriends --shell-file /mnt/project-scripts/seed_odoo.py

Los archivos CSV se montan en /mnt/demo-data (solo lectura). Todo el conjunto
usa datos FICTICIOS: los dominios .example.test no corresponden a clientes.
"""
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import base64
import csv

DATA = Path('/mnt/demo-data')
LIMA = ZoneInfo('America/Lima')


def rows(filename):
    with (DATA / filename).open('r', encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def local_to_utc(value):
    """Las horas CSV son locales de Lima; Odoo guarda UTC internamente."""
    date_local = datetime.strptime(value, '%Y-%m-%d %H:%M:%S').replace(tzinfo=LIMA)
    return date_local.astimezone(timezone.utc).replace(tzinfo=None)


def upsert(model, criteria, vals):
    record = model.search(criteria, limit=1)
    if not record:
        record = model.create(vals)
    return record


def seed_database(env):
    # 1. La misma moneda de los CSV y los presupuestos.
    company = env.company
    currency = env['res.currency'].search([('name', '=', 'PEN')], limit=1)
    if not currency:
        raise ValueError('Moneda PEN no disponible en esta base; revisar instalación del país PE')
    currency.active = True
    company.write({'name': 'MyPetsFriends', 'currency_id': currency.id,
                   'country_id': env.ref('base.pe').id})
    icon = Path('/mnt/extra-addons/mypetsfriends_vet/static/description/icon.png')
    if icon.exists():
        company.logo = base64.b64encode(icon.read_bytes())

    # 2. Una tarifa PEN evita presupuestos en moneda de otra compañía.
    Pricelist = env['product.pricelist']
    if not Pricelist.search([('currency_id', '=', currency.id),
                              ('company_id', 'in', [False, company.id])], limit=1):
        Pricelist.create({'name': 'Tarifa MyPetsFriends PEN',
                          'currency_id': currency.id, 'company_id': company.id})

    # 3. Contactos, diferenciados entre propietarios y proveedores.
    Partners = env['res.partner']
    for filename, rank, company_type in [
        ('propietarios.csv', 'customer_rank', 'person'),
        ('proveedores.csv', 'supplier_rank', 'company'),
    ]:
        for item in rows(filename):
            vals = {k: item[k] for k in ('name', 'email', 'phone', 'street', 'city')}
            vals.update({rank: 1, 'company_type': company_type})
            upsert(Partners, [('email', '=', item['email'])], vals)

    # 4. Categorías, 30 bienes físicos y cuatro servicios.
    Category = env['product.category']
    vet_root = upsert(Category, [('name', '=', 'Veterinaria MPF')], {'name': 'Veterinaria MPF'})
    Product = env['product.template']
    for item in rows('productos.csv'):
        category = upsert(Category, [('name', '=', item['categoria']), ('parent_id', '=', vet_root.id)],
                          {'name': item['categoria'], 'parent_id': vet_root.id})
        vals = {
            'name': item['name'], 'default_code': item['default_code'],
            'type': 'consu', 'is_storable': True, 'sale_ok': True, 'purchase_ok': True,
            'list_price': float(item['list_price']), 'standard_price': float(item['standard_price']),
            'categ_id': category.id, 'invoice_policy': 'delivery',
        }
        upsert(Product, [('default_code', '=', item['default_code'])], vals)
    for item in rows('servicios.csv'):
        vals = {'name': item['name'], 'default_code': item['default_code'],
                'type': 'service', 'sale_ok': True, 'list_price': float(item['list_price']),
                'categ_id': vet_root.id, 'invoice_policy': 'order'}
        upsert(Product, [('default_code', '=', item['default_code'])], vals)

    # 5. Pacientes: asociación única por nombre y correo del propietario.
    Pets = env['vet.pet']
    for item in rows('mascotas.csv'):
        owner = Partners.search([('email', '=', item['owner_email'])], limit=1)
        if not owner:
            raise ValueError('Propietario no encontrado: ' + item['owner_email'])
        vals = {k: item[k] for k in ('name','species','breed','sex','birth_date','chip','allergies')}
        vals.update({'owner_id': owner.id, 'weight_kg': float(item['weight_kg'])})
        upsert(Pets, [('name', '=', item['name']), ('owner_id', '=', owner.id)], vals)

    # 6. Existencia inicial: ajustes de inventario en almacén de la compañía.
    warehouse = env['stock.warehouse'].search([('company_id', '=', company.id)], limit=1)
    if not warehouse:
        raise ValueError('Sin almacén; verificar que Inventario esté instalado')
    Quant = env['stock.quant'].with_context(inventory_mode=True)
    for item in rows('stock_inicial.csv'):
        product = env['product.product'].search([('default_code','=',item['default_code'])], limit=1)
        desired = float(item['quantity'])
        quants = Quant.search([('product_id','=',product.id),('location_id','=',warehouse.lot_stock_id.id)])
        actual = sum(quants.mapped('quantity'))
        if abs(actual - desired) < 0.001:
            continue
        quant = quants[:1] or Quant.create({'product_id': product.id,
                                           'location_id': warehouse.lot_stock_id.id})
        quant.inventory_quantity = desired
        quant.action_apply_inventory()

    # 7. Citas de muestra para comprobar agenda y estados.
    Appointments = env['vet.appointment']
    for item in rows('citas.csv'):
        owner = Partners.search([('email', '=', item['owner_email'])], limit=1)
        pet = Pets.search([('owner_id', '=', owner.id), ('name', '=', item['pet_name'])], limit=1)
        service = env['product.product'].search([('default_code', '=', item['service_code'])], limit=1)
        at = local_to_utc(item['scheduled_at'])
        criteria = [('pet_id','=',pet.id),('scheduled_at','=',at)]
        vals = {'pet_id': pet.id, 'service_id': service.id, 'vet_id': env.user.id,
                'scheduled_at': at, 'duration_minutes': int(item['duration_minutes']),
                'reason': item['reason'], 'state': item['state']}
        upsert(Appointments, criteria, vals)

    # 8. Carnet de vacunación (5 registros con lotes y fechas de refuerzo).
    Vaccines = env['vet.vaccination']
    for item in rows('vacunaciones.csv'):
        owner = Partners.search([('email', '=', item['owner_email'])], limit=1)
        pet = Pets.search([('owner_id', '=', owner.id), ('name', '=', item['pet_name'])], limit=1)
        product = env['product.product'].search([('default_code','=',item['product_code'])],limit=1)
        vals = {'pet_id': pet.id, 'vaccine_name': item['vaccine_name'],
                'product_id': product.id, 'date': item['date'],
                'next_date': item['next_date'], 'batch': item['batch']}
        upsert(Vaccines, [('pet_id','=',pet.id),('batch','=',item['batch'])], vals)

    # 9. Una atención histórica de muestra. Luna se mantiene SIN atender
    # para que se pueda ejecutar la demostración completa en la interfaz.
    max_appointment = Appointments.search([('pet_id.name','=','Max')], limit=1)
    if max_appointment and not max_appointment.consultation_id:
        consultation = env['vet.consultation'].create({
            'appointment_id': max_appointment.id, 'pet_id': max_appointment.pet_id.id,
            'vet_id': env.user.id, 'reason': 'Vacunación de control',
            'symptoms': 'Paciente activo, condición general estable',
            'diagnosis': 'Paciente clínicamente apto para vacunación',
            'treatment': 'Aplicación de esquema preventivo',
            'recommendations': 'Observar evolución y controlar refuerzo anual',
            'weight_kg': 27.2,
        })
        max_appointment.consultation_id = consultation.id
        vaccine = env['product.product'].search([('default_code','=','MPF003')],limit=1)
        env['vet.consultation.item'].create({
            'consultation_id': consultation.id,
            'product_id': vaccine.id, 'quantity': 1,
            'notes': 'Vacuna aplicada en consulta',
        })
        consultation.action_finish()

    # Odoo shell revierte la transacción al salir si no hacemos commit.
    env.cr.commit()
    print('\n=== MyPetsFriends: datos guardados ===')
    for model, label, domain in [
        ('res.partner', 'Propietarios ficticios', [('email','like','example.test'),('customer_rank','>',0)]),
        ('res.partner', 'Proveedores ficticios', [('email','like','example.test'),('supplier_rank','>',0)]),
        ('product.template', 'Productos', [('default_code','like','MPF')]),
        ('product.template', 'Servicios', [('default_code','like','SRV')]),
        ('vet.pet', 'Mascotas', []),
        ('vet.appointment', 'Citas', []),
        ('vet.consultation', 'Consultas', []),
        ('vet.vaccination', 'Vacunaciones', []),
    ]:
        print(f'{label}: {env[model].search_count(domain)}')
    print('Moneda de la empresa:', env.company.currency_id.name)
    print('Abre la cita de Luna y sigue docs/04_CASO_DEMOSTRACION.md')


# `env` es la variable que Odoo inyecta a `shell --shell-file`.
seed_database(env)
