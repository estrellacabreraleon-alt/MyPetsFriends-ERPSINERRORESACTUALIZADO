"""Restauración en base SEPARADA, sin modificar la original."""
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import read_env
ROOT = Path(__file__).resolve().parents[1]


def main():
    settings = read_env(ROOT / '.env')
    path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
    if not path or not path.is_file() or path.suffix != '.zip':
        sys.exit('Uso: python scripts/restore_test.py backups/archivo_respaldo.zip')
    db_restore = settings['ODOO_DB'] + '_prueba'
    q = f"SELECT 1 FROM pg_database WHERE datname='{db_restore}';"
    check = subprocess.run(['docker','compose','exec','-T','db','psql','-U',settings['POSTGRES_USER'],
                            '-d','postgres','-At','-c',q], cwd=ROOT, text=True, capture_output=True, check=True)
    if check.stdout.strip() == '1':
        sys.exit(f'No se sobrescribe {db_restore}. Eliminarla manualmente, después de validar que no contiene datos importantes.')
    cmd = ['docker','compose','run','--rm','--no-deps', '-v', f'{path.parent}:/backups:ro',
           'odoo','odoo','db','load',db_restore,f'/backups/{path.name}','--neutralize']
    subprocess.run(cmd, cwd=ROOT, check=True)
    print('Restauración ejecutada. Verifica la base con:')
    print('docker compose exec -T db psql -U ' + settings['POSTGRES_USER'] + ' -d ' + db_restore + ' -c "SELECT count(*) FROM vet_pet;"')
    print('El ERP original no ha sido reemplazado. Se usó una base distinta.')


if __name__ == '__main__':
    main()
