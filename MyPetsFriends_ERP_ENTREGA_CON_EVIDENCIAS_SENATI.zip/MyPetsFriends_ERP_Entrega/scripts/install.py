"""Instalación guiada desde Windows, macOS o Linux: python scripts/install.py.

Requiere Docker Desktop/Engine encendido. No elimina datos preexistentes.
Odoo 20 documenta oficialmente `odoo db init`; módulos con -i.
"""
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from prepare import read_env, main as prepare


def run(*args, capture=False):
    cmd = ['docker', 'compose', *args]
    print('> docker compose ' + ' '.join(str(a) if 'password' not in str(a).lower() else '[protegido]' for a in args[:2]), flush=True)
    return subprocess.run(cmd, cwd=ROOT, check=True, text=True,
                          stdout=subprocess.PIPE if capture else None, stderr=subprocess.PIPE if capture else None)


def main():
    prepare()
    if not shutil.which('docker'):
        sys.exit('Falta Docker. Instala Docker Desktop y comprueba `docker compose version`.')
    settings = read_env(ROOT / '.env')
    db = settings['ODOO_DB']
    # Comprobación inicial. No se elimina volumen ni base alguna.
    subprocess.run(['docker', 'compose', 'version'], cwd=ROOT, check=True)
    print('Iniciando PostgreSQL...')
    run('up', '-d', 'db')
    for attempt in range(40):
        ok = subprocess.run(['docker', 'compose', 'exec', '-T', 'db', 'pg_isready', '-U', settings['POSTGRES_USER'], '-d', 'postgres'],
                            cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if ok.returncode == 0:
            break
        time.sleep(2)
    else:
        sys.exit('PostgreSQL no está listo. Revisar: docker compose logs db')

    # Comprueba existencia por SQL en vez de intentar inicializar dos veces.
    q = "SELECT 1 FROM pg_database WHERE datname = '%s';" % db
    result = run('exec', '-T', 'db', 'psql', '-U', settings['POSTGRES_USER'], '-d', 'postgres', '-At', '-c', q, capture=True)
    if result.stdout.strip() != '1':
        print('Creando base de datos Odoo (sin datos de demostración estándar)...')
        # La contraseña se pasa al contenedor en esta única llamada local, no se imprime.
        run('run', '--rm', '--no-deps', 'odoo', 'odoo', 'db', 'init', db,
            '--country', 'PE', '--language', 'es_PE',
            '--username', settings['ODOO_ADMIN_LOGIN'], '--password', settings['ODOO_ADMIN_PASSWORD'])
    else:
        print('Base existente detectada: se conserva')

    print('Instalando dependencias estándar y módulo veterinario...')
    run('run', '--rm', '--no-deps', 'odoo', 'odoo',
        '-d', db, '-i', 'mypetsfriends_vet', '--stop-after-init', '--without-demo')
    run('up', '-d', 'odoo')
    print(f'ERP preparado en http://localhost:{settings["ODOO_PORT"]}')
    print('El usuario y la clave inicial están en el archivo privado .env')
    print('Para insertar datos de prueba: python scripts/load_demo.py')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as exc:
        sys.exit(f'Comando Docker falló (código {exc.returncode}). Revisar logs y guía de diagnóstico.')
