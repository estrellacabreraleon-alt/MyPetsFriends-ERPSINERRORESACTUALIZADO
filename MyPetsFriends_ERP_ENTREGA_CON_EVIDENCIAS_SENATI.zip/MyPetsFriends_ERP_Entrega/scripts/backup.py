"""Respaldo integral Odoo en ZIP: SQL + filestore. No guarda claves en el ZIP."""
from pathlib import Path
from datetime import datetime
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import read_env
ROOT = Path(__file__).resolve().parents[1]


def main():
    values = read_env(ROOT / '.env')
    backups = ROOT / 'backups'
    backups.mkdir(exist_ok=True)
    filename = f'{values["ODOO_DB"]}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip'
    cmd = ['docker', 'compose', 'run', '--rm', '--no-deps',
           '-v', f'{backups.resolve()}:/backups',
           'odoo', 'odoo', 'db', 'dump', values['ODOO_DB'], f'/backups/{filename}', '--format', 'zip']
    subprocess.run(cmd, cwd=ROOT, check=True)
    path = backups / filename
    if not path.is_file() or path.stat().st_size == 0:
        raise RuntimeError('No se generó el respaldo: revisar salida del comando')
    print(f'Respaldo generado: {path} ({path.stat().st_size:,} bytes)')


if __name__ == '__main__':
    main()
